#NITJ CAR RENTAL-Prject
NITJ CAR RENTAL:
Nitj car rental is yet another learning time project developed in Java, the idea about it came when we see there is a lot of transport problem in Nitj as it is very far from the city.
What it does is, it simply takes the user's details and the car that the user is booking.
With time we add more features to this project to provide more user-friendly interfaces.

Features of NITJ CAR RENTAL:

1. GUI is simple and user-friendly.
2. Taking only the basic details of the user.
3. Show the options of car and show full details and price of each car.
4. Price is also getting automatically calculated.
5. At user get all the information in a text file.
6. Well tested.
